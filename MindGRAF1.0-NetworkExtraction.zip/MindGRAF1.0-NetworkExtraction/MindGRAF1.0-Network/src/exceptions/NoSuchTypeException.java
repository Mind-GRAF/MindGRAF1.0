package exceptions;

public class NoSuchTypeException extends Exception{

	public NoSuchTypeException() {
		super();
	}
	public NoSuchTypeException(String s) {
		super(s);
	}
	

}
