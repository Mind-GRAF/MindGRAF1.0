package exceptions;

public class CannotRemoveNodeException extends Exception{

	public CannotRemoveNodeException() {
		super();
	}
	public CannotRemoveNodeException(String s) {
		super(s);
	}
}
