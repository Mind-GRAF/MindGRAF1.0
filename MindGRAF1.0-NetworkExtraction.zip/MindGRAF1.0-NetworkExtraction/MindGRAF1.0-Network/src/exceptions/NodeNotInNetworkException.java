package exceptions;

public class NodeNotInNetworkException extends Exception{

	public NodeNotInNetworkException() {
		super();
	}
	public NodeNotInNetworkException(String s) {
		super(s);
	}
}
