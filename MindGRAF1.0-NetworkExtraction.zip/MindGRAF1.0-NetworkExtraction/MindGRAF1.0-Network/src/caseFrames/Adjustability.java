package caseFrames;

public enum Adjustability {
	EXPAND,REDUCE,NONE
}
