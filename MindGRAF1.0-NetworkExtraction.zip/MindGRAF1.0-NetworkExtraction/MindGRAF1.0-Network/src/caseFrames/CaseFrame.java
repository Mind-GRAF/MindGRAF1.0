package caseFrames;

public class CaseFrame {

	public CaseFrame() {
		// TODO Auto-generated constructor stub
	}

}
