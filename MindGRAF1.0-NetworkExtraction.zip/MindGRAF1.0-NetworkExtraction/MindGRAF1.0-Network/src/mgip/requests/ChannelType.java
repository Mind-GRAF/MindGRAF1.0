package mgip.requests;

public enum ChannelType {
    Matched, AntRule, RuleCons, Act;
}
