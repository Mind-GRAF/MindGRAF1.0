package mgip;

public enum InferenceType {
    FORWARD, BACKWARD;
}
