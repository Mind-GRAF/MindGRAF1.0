package mgip;

public enum ReportType {
    Matched, AntRule, RuleCons;
}
