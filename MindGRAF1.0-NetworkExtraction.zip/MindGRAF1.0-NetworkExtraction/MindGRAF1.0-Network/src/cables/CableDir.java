package cables;

public enum CableDir {
	UP,DOWN
}
