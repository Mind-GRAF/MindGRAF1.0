//package cables;
//
//import java.util.Collection;
//import java.util.HashMap;
//
//
//public abstract class CableSet {
//	
//	public CableSet(){
//		super();
//	}
//	
//
//	abstract public Cable get(String key);
//	
//	abstract public int size();
//	
//	abstract public boolean contains(Object s);
//	
//}
