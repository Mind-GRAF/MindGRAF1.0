package nodes;

public enum Agenda {
  START,
  FIND_PRECONDITIONS,
  TEST,
  FIND_EFFECTS,
  FIND_PLANS,
  EXECUTE,
  DONE
}