package nodes;

package nodes;

import java.util.ArrayList;

import exceptions.NoSuchTypeException;
import mgip.Report;
import mgip.Scheduler;
import mgip.requests.ChannelType;
import network.Network;
import set.NodeSet;

class Sniterate extends ControlAct{

    private ArrayList<nodes.ActNode> actList;

    public Sniterate(String controlType) {
        super("SNITERATE");
        //TODO Auto-generated constructor stub
    }

    public void execute() {
        switch(agenda){
            case START:
            agenda = Agenda.TEST;
            Scheduler.addToActQueue(this);
            ArrayList<PropositionNode> guards = new ArrayList<>();
                Node z;
                try {
                    z = Network.createVariableNode("z", "propositionnode");
                } catch (NoSuchTypeException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
			NodeSet guard = new NodeSet(this,z);

            for (int i=1; i<=intg;i++){

			establishChannel(ChannelType.Act,"guards" ,new mgip.matching.Substitutions(),new mgip.matching.Substitutions(), context.Controller.getCurrentContext().getName(),i,0,z);
							}
            case TEST:
            agenda= Agenda.DONE;
            
                //reprots =RecieveReports()
            for(Report report: reports){
									if(report.isSign() == false){
										reports.remove(report);
									}
                                    else{
                                        actList.add(this);
                                    }
								}
            //SNSEQUENCE
            Scheduler.addToActQueue(this);
            default:
            break;
        }
    }

}