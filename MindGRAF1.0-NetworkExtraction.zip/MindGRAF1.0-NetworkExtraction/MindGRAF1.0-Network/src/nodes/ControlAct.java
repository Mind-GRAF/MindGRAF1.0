package nodes;

import exceptions.NoSuchTypeException;
import network.Network;

public class ControlAct extends ActNode {
    public static final ControlAct SNSEQUENCE = new ControlAct("SNSEQUENCE");
    public static final ControlAct SNIF = new ControlAct("SNIF");
    public static final ControlAct SNITERATE = new ControlAct("SNITERATE");
    public static final ControlAct ACHIEVE = new ControlAct("ACHIEVE");
    public static final ControlAct DoONE = new ControlAct("DoONE");
    public static final ControlAct DoALL = new ControlAct("DoALL");

    private String controlType;

    public ControlAct(String controlType) {
        super(controlType, null);
        this.controlType = controlType;
    }

    @Override
    public void execute() {
        // This method will be overridden in subclasses.
    }

    public static void initiateControl() throws NoSuchTypeException  {
       Node SNSEQUENCE =Network.createNode("SNSEQUENCE", "ActNode");
        Node SNIF=(Network.createNode("SNIF", "ActNode"));
        Node SNITERATE=(Network.createNode("SNITERATE", "ActNode"));
        Node ACHIEVE=(Network.createNode("ACHIEVE", "ActNode"));
        Node DoONE=(Network.createNode("DoONE", "ActNode"));
        Node DoALL=(Network.createNode("DoALL", "ActNode"));
    }
}
