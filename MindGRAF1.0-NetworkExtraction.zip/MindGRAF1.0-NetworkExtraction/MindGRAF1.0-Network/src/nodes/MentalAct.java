package nodes;

public class MentalAct extends ActNode{

    public MentalAct(String name, Boolean isVariable) {
        super(name, isVariable);
        //TODO Auto-generated constructor stub
    }

    public void execute() {
        // This method will be overridden in subclasses.
    }
    
}
