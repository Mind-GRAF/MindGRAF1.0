package nodes;
import java.util.ArrayList;
import java.util.Stack;
import mgip.Scheduler;
class Snsequence extends nodes.ControlAct {

    private ArrayList<nodes.ActNode> actList;

    public Snsequence(ArrayList<nodes.ActNode> actList) {
        super("SNSEQUENCE");
        this.actList = actList;
    }

    @Override
    public void execute() {
        ArrayList<nodes.ActNode> scheduledActs = new ArrayList<>();

        Stack<nodes.ActNode> actsToSchedule = new Stack<>();

        for (int i = actList.size() - 1; i >= 0; i--) {
            nodes.ActNode act = actList.get(i);

            act.restartAgenda();

            actsToSchedule.push(act);
        }

        while (!actsToSchedule.isEmpty()) {
            nodes.ActNode act = actsToSchedule.pop();
            Scheduler.addToActQueue(act);

            scheduledActs.add(act);
        }

       
    }

}