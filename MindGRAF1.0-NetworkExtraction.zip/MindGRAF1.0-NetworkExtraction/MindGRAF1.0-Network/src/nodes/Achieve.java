package nodes;

package nodes;

import java.util.ArrayList;

import exceptions.NoSuchTypeException;
import mgip.Report;
import mgip.Scheduler;
import mgip.requests.ChannelType;
import network.Network;
import set.NodeSet;

class ACHIEVE extends ControlAct{

    private ArrayList<nodes.ActNode> actList;

    private ArrayList<Report> reports;
    public ACHIEVE(String controlType) {
        super("ACHIEVE");
        //TODO Auto-generated constructor stub
    }

    public void execute() {
        switch(agenda){
            case START:
            if{
                Attitude accept= new Attitude(reports.attitudeid,this);
                break;
            }
            else{

                agenda=Agenda.FIND_PLANS;
                Node y= Network.createVariableNode("y", "propositionnode");
				NodeSet plans = new NodeSet(this, y);


                for (int i=1; i<=intg;i++){

				establishChannel(ChannelType.Act,"plan" ,new mgip.matching.Substitutions(),new mgip.matching.Substitutions(), context.Controller.getCurrentContext().getName(),i,0,y);
							}
            }
         case FIND_PLANS:
    
         ArrayList<PropositionNode> plans;
         //recieve reports==> add to plans
         if(!plans.isEmpty()){
            agenda= Agenda.DONE;
            Scheduler.addToActQueue(this);
         }
         else{
            System.out.println("Physical Act will be used to recieve plans!");
         }



          
            default:
            break;
        }
    }

}