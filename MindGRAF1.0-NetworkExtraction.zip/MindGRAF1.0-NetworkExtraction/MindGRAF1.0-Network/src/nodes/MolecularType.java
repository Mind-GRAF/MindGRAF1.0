package nodes;

public enum MolecularType {
	OPEN,CLOSED
}
