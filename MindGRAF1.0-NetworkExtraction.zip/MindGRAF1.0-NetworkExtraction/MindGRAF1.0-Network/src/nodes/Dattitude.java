package nodes;

import java.util.List;

import mgip.Report;
import mgip.Scheduler;

public class Dattitude extends MentalAct{

      private int intgs;

    public Dattitude(String name, Boolean isVariable) {
        super(name, isVariable);
        //TODO Auto-generated constructor stub
    }


    public void execute(ActNode act){

        Report report = new Report(null, null, intg, false, null, act);
        Scheduler.addToHighQueue(report);

    }
    
}
