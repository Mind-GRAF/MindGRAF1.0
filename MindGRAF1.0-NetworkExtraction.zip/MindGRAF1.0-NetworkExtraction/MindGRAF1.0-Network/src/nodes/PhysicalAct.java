package nodes;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.ToolProvider;

public class PhysicalAct extends ActNode {
    public PhysicalAct(String name, Boolean isVariable) {
        super(name, isVariable);
        //TODO Auto-generated constructor stub
    }
    private String userInputCode;
    private String className;

   

    @Override
    public void execute() {
        // Get the Java compiler.
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        // Create an output stream to capture compiler errors.
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        // Create a dynamic class object.
        DynamicJavaFileObject dynamicJavaFileObject = new DynamicJavaFileObject(className, userInputCode);
        // Create a compilation task.
        Iterable<? extends JavaFileObject> compilationUnits = Arrays.asList(dynamicJavaFileObject);
        CompilationTask task = compiler(outputStream, null, null, null, null, compilationUnits);
        // Execute the compilation task.
        boolean success = task.call();
        // If the compilation was successful, load the dynamic class and invoke its method.
        if (success) {
            try {
                Class<?> dynamicClass = Class.forName(className);
                Object dynamicObject = dynamicClass.getDeclaredConstructor().newInstance();
                Method dynamicMethod = dynamicClass.getDeclaredMethod("dynamicMethod");
                dynamicMethod.invoke(dynamicObject);
            } catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
        } else {
            // If the compilation failed, print the error message to the standard error stream.
            System.err.println(outputStream.toString());
        }
    }
// due to need to download certain jar only for eclipse not vs yet applicable 
    private CompilationTask compiler(ByteArrayOutputStream outputStream, Object object, Object object2, Object object3,
            Object object4, Iterable<? extends JavaFileObject> compilationUnits) {
        return null;
    }
}

class DynamicJavaFileObject extends SimpleJavaFileObject {
    private String code;

    public DynamicJavaFileObject(String name, String code) {
        super(URI.create("string:///" + name.replace('.', '/') + Kind.SOURCE.extension), Kind.SOURCE);
        this.code = code;
    }

    @Override
    public CharSequence getCharContent(boolean ignoreEncodingErrors) {
        return code;
    }

    public byte[] getCompiledBytes() {
        return null;
    }
}

class DynamicClassLoader extends ClassLoader {
    private final Map<String, DynamicJavaFileObject> fileObjects = new HashMap<>();

    public DynamicClassLoader(ClassLoader parent) {
        super(parent);
    }

    public void addJavaFileObject(DynamicJavaFileObject fileObject) {
        fileObjects.put(fileObject.getName(), fileObject);
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        DynamicJavaFileObject fileObject = fileObjects.get(name);
        if (fileObject != null) {
            byte[] bytes = fileObject.getCompiledBytes();
            return defineClass(name, bytes, 0, bytes.length);
        }
        try {
            return ClassLoader.getSystemClassLoader().loadClass(name);
        } catch (ClassNotFoundException e) {
            return super.findClass(name);
        }
    }
}
