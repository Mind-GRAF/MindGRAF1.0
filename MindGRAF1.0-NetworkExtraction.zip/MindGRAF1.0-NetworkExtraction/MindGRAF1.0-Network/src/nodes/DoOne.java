package nodes;

import mgip.Scheduler;
import java.util.ArrayList;
import java.util.Random;

class DoOne extends ControlAct {

    private ArrayList<nodes.ActNode> actList;

    public DoOne(ArrayList<nodes.ActNode> actList) {
        super("DoOne");
        this.actList = actList;
    }

    @Override
    public void execute() {
        // Get a random number generator.
        Random random = new Random();
        // Create an array to store the possible acts.
        ArrayList<nodes.ActNode> allPossible = new ArrayList<>();

        // Iterate over the act list.
        for (nodes.ActNode act : actList) {
            // Add the act to the possible acts array.
            allPossible.add(act);
        }

        // Get a random index from the possible acts array.
        int actIndex = random.nextInt(allPossible.size());

        // Add the act with the random index to the scheduler.
        nodes.ActNode act = allPossible.get(actIndex);
        Scheduler.addToActQueue(act);
        act.restartAgenda();

    }

}
