package nodes;
import cables.DownCableSet;

public class PropositionNode extends Node {

    public String name;

    public PropositionNode(String name , Boolean isVariable) {
        super(name,isVariable);
    }

    public PropositionNode( DownCableSet downCableSet) {
    	super(downCableSet);
    }

    
   public  String getName(){
    return this.name;
   }
  
}
