package nodes;

public enum Syntactic {
	TERM,BASE,MOLECULAR,VARIABLE
}
