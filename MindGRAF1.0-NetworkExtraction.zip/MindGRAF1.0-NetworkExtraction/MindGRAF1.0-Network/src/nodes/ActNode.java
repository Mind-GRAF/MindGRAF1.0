package nodes;

import java.nio.channels.Channel;
import java.util.ArrayList;

import cables.DownCableSet;
import components.Substitutions;
import context.Context;
import exceptions.NoSuchTypeException;
import mgip.Report;
import mgip.Scheduler;
import mgip.requests.ActChannel;
import mgip.requests.AntecedentToRuleChannel;
import mgip.requests.ChannelSet;
import mgip.requests.ChannelType;
import mgip.requests.MatchChannel;
import mgip.requests.Request;
import mgip.requests.RuleToConsequentChannel;
import network.Network;
import set.NodeSet;

public class ActNode extends Node{
	
	protected ChannelSet outgoingChannels;



	public Agenda agenda;
	public int intg;

	public ActNode(String name , Boolean isVariable) {
	        super(name,isVariable);
	    }

	    public ActNode( DownCableSet downCableSet ) {
	        super(downCableSet);
	    }

	
    
	 public void intend() throws NoSuchTypeException {

			switch(agenda){

				case START: 
							agenda= Agenda.FIND_PRECONDITIONS;
							Scheduler.addToActQueue(this);
							Node x = Network.createVariableNode("X", "propositionnode");
							NodeSet precon = new NodeSet(this, x);
							for (int i=1; i<=intg;i++){

								establishChannel(ChannelType.Act,"Precondition" ,new mgip.matching.Substitutions(),new mgip.matching.Substitutions(), context.Controller.getCurrentContext().getName(),i,0,x);
							}
				case FIND_PRECONDITIONS:
							ArrayList<PropositionNode> precondition = new ArrayList<>();
							ArrayList<Report> reports = new ArrayList<>();
							// reports = recieveReports();
							if(!precondition.isEmpty()){
								agenda =Agenda.TEST;
								Scheduler.addToActQueue(this);
								for(Report report: reports){
									if(report.isSign() == false){
										reports.remove(report);
									}
								}
							}
							else{
								agenda= Agenda.FIND_EFFECTS;
								Scheduler.addToActQueue(this);
								Node y= Network.createVariableNode("y", "propositionnode");
								NodeSet effect = new NodeSet(this, y);
								for (int i=1; i<=intg;i++){

								establishChannel(ChannelType.Act,"actEffect" ,new mgip.matching.Substitutions(),new mgip.matching.Substitutions(), context.Controller.getCurrentContext().getName(),i,0,y);
							}
							}
				case TEST:
				ArrayList<PropositionNode> preconditionn = new ArrayList<>();
							ArrayList<Report> reportt = new ArrayList<>();
							if(!preconditionn.isEmpty()){
								agenda =Agenda.TEST;
								Scheduler.addToActQueue(this);
								for(Report report: reportt){
									if(report.isSign() == false){
										reportt.remove(report);
									}
								}
							}
							else{
								agenda = Agenda.FIND_EFFECTS;
								Scheduler.addToActQueue(this);
								Node y= Network.createVariableNode("y", "propositionnode");
								NodeSet effect = new NodeSet(this, y);
								for (int i=1; i<=intg;i++){

								establishChannel(ChannelType.Act,"actEffect" ,new mgip.matching.Substitutions(),new mgip.matching.Substitutions(), context.Controller.getCurrentContext().getName(),i,0,y);
							}
							}
				case FIND_EFFECTS:
							ArrayList<PropositionNode> effect = new ArrayList<>();
							ArrayList<Report> report2 = new ArrayList<>();
							if(!effect.isEmpty()){
								//Attitude accept= new Attitude(report2.attitudeid,this);
							}
							agenda = Agenda.EXECUTE;

				default:
					break;

			}
        }

		

		


// will be overriden
		public void execute(){

		}


        public void restartAgenda() {

			agenda = Agenda.START;

        }

	///////////////////////////////////////////////////////////////////////////////////////////////










	
		protected Request establishChannel(ChannelType type, Node targetNode,
            Substitutions switchSubs,
            Substitutions filterSubs, String contextName,
            int attitudeId,
            int matchType, Node requesterNode) {
        /* BEGIN - Helpful Prints */
        String reporterIdent = targetNode.getName();
        String requesterIdent = requesterNode.getName();
        System.out.println("Trying to establish a channel from " + requesterIdent + " to " + reporterIdent);
        /* END - Helpful Prints */
        Substitutions switchSubstitutions = switchSubs == null ? new Substitutions()
                : switchSubs;
        Substitutions filterSubstitutions = filterSubs == null ? new Substitutions()
                : filterSubs;
        Channel newChannel;
        switch (type) {
            case Matched:
                newChannel = (Channel) new MatchChannel(switchSubstitutions, filterSubstitutions,
                        contextName, attitudeId,
                        matchType, requesterNode);
                break;
            case AntRule:
                newChannel = (Channel) new AntecedentToRuleChannel(switchSubstitutions,
                        filterSubstitutions, contextName,
                        attitudeId,
                        requesterNode);
                break;
            case RuleCons:
                newChannel = (Channel) new RuleToConsequentChannel(switchSubstitutions,
                        filterSubstitutions, contextName,
                        attitudeId,
                        requesterNode);
                break;
            default:
                newChannel = (Channel) new ActChannel(switchSubstitutions,
                        filterSubstitutions, contextName,
                        attitudeId,
                        requesterNode);
                break;

        }
        Channel currentChannel;
        if (type == ChannelType.Act) {
            currentChannel = ((ActNode) targetNode).getOutgoingChannels().getChannel(newChannel);

        } else {
            currentChannel = ((ActNode) targetNode).getOutgoingChannels().getChannel(newChannel);

        }
        if (currentChannel == null) {
            /* BEGIN - Helpful Prints */
            System.out.println("Channel of type " + ((mgip.requests.Channel) newChannel).getChannelType()
                    + " is successfully created and used for further operations");
            /* END - Helpful Prints */
            Request newRequest = new Request((mgip.requests.Channel) newChannel, targetNode);
            if (type == ChannelType.Act) {
                ((ActNode) targetNode).addToOutgoingChannels(newChannel);

            } else {
                ((ActNode) targetNode).addToOutgoingChannels(newChannel);

            }
            return newRequest;
        }

        /* BEGIN - Helpful Prints */
        System.out.println(
                "Channel of type " + ((mgip.requests.Channel) currentChannel).getChannelType()
                        + " was already established and re-enqueued for further operations");
        /* END - Helpful Prints */
        return new Request((mgip.requests.Channel) currentChannel, targetNode);

    }

	public ChannelSet getOutgoingChannels() {
        return outgoingChannels;
    }

    public void setOutgoingChannels(ChannelSet outgoingChannels) {
        this.outgoingChannels = outgoingChannels;
    }

	public void addToOutgoingChannels(Channel newChannel) {
        outgoingChannels.addChannel((mgip.requests.Channel) newChannel);
    }

	public void establishChannel(ChannelType act, String nodeName, mgip.matching.Substitutions substitutions,
			mgip.matching.Substitutions substitutions2, String name, int i, int matchType, Node x) {
	}
	  
}

