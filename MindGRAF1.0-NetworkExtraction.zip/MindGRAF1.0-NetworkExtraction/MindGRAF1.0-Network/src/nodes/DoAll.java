package nodes;
import java.util.ArrayList;
import java.util.Random;
import mgip.Scheduler;
class Doall extends nodes.ControlAct {

    private ArrayList<nodes.ActNode> actList;

    public Doall(ArrayList<nodes.ActNode> actList) {
        super("DoALL");
        this.actList = actList;
    }

    @Override
    public void execute() {
    
        Random random = new Random();

        ArrayList<nodes.ActNode> allPossible = new ArrayList<>();

        
        for (nodes.ActNode act : actList) {
            allPossible.add(act);
        }

        while (allPossible.size() > 0) {

            int actIndex = random.nextInt(allPossible.size());

            nodes.ActNode act = allPossible.get(actIndex);
            Scheduler.addToActQueue(act);
            allPossible.remove(actIndex);
            act.restartAgenda();

        }
    }

}
