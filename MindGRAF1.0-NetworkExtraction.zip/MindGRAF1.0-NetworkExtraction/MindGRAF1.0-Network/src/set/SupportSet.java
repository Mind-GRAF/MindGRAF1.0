package set;

public class SupportSet extends Set{
	
}
